import os
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'forum_project.settings')  # Χρησιμοποιήστε το ΣΩΣΤΟ όνομα

import django
django.setup()

from forum.models import Category

if not Category.objects.exists():
    parent = Category.objects.create(name="Γονική", slug="parent")
    Category.objects.create(name="Παιδική", slug="child", parent=parent)
    print("✅ Δημιουργήθηκαν νέες κατηγορίες!")
else:
    print("ℹ️ Οι κατηγορίες υπάρχουν ήδη. Πλήθος:", Category.objects.count())
	