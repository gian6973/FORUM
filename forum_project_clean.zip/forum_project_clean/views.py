from django.contrib.auth.decorators import login_required
from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth import login
from django.contrib import messages
from .forms import ProfileForm, SignUpForm
from .models import Category, Thread

@login_required
def profile_edit_view(request):
    if request.method == 'POST':
        form = ProfileForm(request.POST, instance=request.user)  # Αλλαγή από UserProfileForm σε ProfileForm
        if form.is_valid():
            form.save()
            messages.success(request, 'Το προφίλ σας ενημερώθηκε με επιτυχία.')
            return redirect('forum:profile_edit')
    else:
        form = ProfileForm(instance=request.user)
    return render(request, 'registration/profile_edit.html', {'form': form})

def category_threads_by_slug(request, **kwargs):
    category_slug = kwargs.get('category_slug')
    category = get_object_or_404(Category, slug=category_slug)
    threads = Thread.objects.filter(category=category).order_by('-created_at')
    return render(request, 'forum/category_threads.html', {
        'category': category,
        'threads': threads
    })

def signup_view(request):
    if request.method == 'POST':
        form = SignUpForm(request.POST)
        if form.is_valid():
            user = form.save()
            login(request, user)
            messages.success(request, 'Η εγγραφή ολοκληρώθηκε με επιτυχία!')
            return redirect('forum:home')
    else:
        form = SignUpForm()
    return render(request, 'registration/signup.html', {'form': form})

