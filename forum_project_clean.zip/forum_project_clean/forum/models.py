from django.db import models
from mptt.models import MPTTModel, TreeForeignKey
from django.contrib.auth.models import User
from django.utils.text import slugify
from django.urls import reverse

class Category(MPTTModel):
    name = models.CharField(max_length=100, unique=True)
    slug = models.SlugField(unique=True, allow_unicode=True)  # Επιτρέπει ελληνικά slugs
    parent = TreeForeignKey(
        'self',
        on_delete=models.CASCADE,
        null=True,
        blank=True,
        related_name='children',
        verbose_name='Γονική Κατηγορία'
    )

    class MPTTMeta:
        order_insertion_by = ['name']
        verbose_name = 'Κατηγορία'
        verbose_name_plural = 'Κατηγορίες'

    class Meta:
        verbose_name = 'Κατηγορία'
        verbose_name_plural = 'Κατηγορίες'

    def __str__(self):
        return self.name
    
    def save(self, *args, **kwargs):
        if not self.slug:
            self.slug = slugify(self.name, allow_unicode=True)
        super().save(*args, **kwargs)
        
    def get_absolute_url(self):
        return reverse('forum:category_threads', kwargs={'category_id': self.id})

class Thread(models.Model):
    title = models.CharField(max_length=200, verbose_name='Τίτλος')
    slug = models.SlugField(unique=True, allow_unicode=True)
    category = models.ForeignKey(
        Category,
        on_delete=models.CASCADE,
        related_name='threads',
        verbose_name='Κατηγορία'
    )
    created_by = models.ForeignKey(
        User,
        on_delete=models.CASCADE,
        related_name='threads',
        verbose_name='Δημιουργός'
    )
    created_at = models.DateTimeField(auto_now_add=True, verbose_name='Ημερομηνία Δημιουργίας')

    class Meta:
        verbose_name = 'Συζήτηση'
        verbose_name_plural = 'Συζητήσεις'
        ordering = ['-created_at']

    def __str__(self):
        return self.title
        
    def save(self, *args, **kwargs):
        if not self.slug:
            self.slug = slugify(self.title, allow_unicode=True)
        super().save(*args, **kwargs)
        
    def get_absolute_url(self):
        return reverse('forum:category_threads', kwargs={'category_id': self.id})

class Post(models.Model):
    thread = models.ForeignKey(
        Thread,
        on_delete=models.CASCADE,
        related_name='posts',
        verbose_name='Συζήτηση'
    )
    content = models.TextField(verbose_name='Περιεχόμενο')
    created_by = models.ForeignKey(
        User,
        on_delete=models.CASCADE,
        related_name='posts',
        verbose_name='Δημιουργός'
    )
    created_at = models.DateTimeField(auto_now_add=True, verbose_name='Ημερομηνία Δημιουργίας')

    class Meta:
        verbose_name = 'Απάντηση'
        verbose_name_plural = 'Απαντήσεις'
        ordering = ['created_at']

    def __str__(self):
        return f'Απάντηση από {self.created_by} στις {self.created_at}'
		
		


	


