#from django.contrib import admin 
#from .models import Category, Thread, Post

#@admin.register(Category)
#class CategoryAdmin(admin.ModelAdmin):
#    list_display = ('name', 'slug', 'parent')
#    prepopulated_fields = {'slug': ('name',)}

#    def view_on_site(self, obj):
#        return obj.get_absolute_url()

#@admin.register(Thread)
#class ThreadAdmin(admin.ModelAdmin):
#    prepopulated_fields = {"slug": ("title",)}
#    list_display = ("title", "slug", "category", "created_by", "created_at")
#    list_filter = ("category", "created_by")
#    search_fields = ("title",)

#    def view_on_site(self, obj):
#        return obj.get_absolute_url()

#@admin.register(Post)
#class PostAdmin(admin.ModelAdmin):
#   list_display = ("thread", "created_by", "created_at")
#   list_filter = ("created_by",)
#   search_fields = ("content",)


#finance/admin
from django.contrib import admin
from .models import Category, Thread, Post

@admin.register(Category)
class CategoryAdmin(admin.ModelAdmin):
    list_display = ('name', 'slug', 'parent')
    prepopulated_fields = {'slug': ('name',)}

    def view_on_site(self, obj):
        return obj.get_absolute_url()

@admin.register(Thread)
class ThreadAdmin(admin.ModelAdmin):
    prepopulated_fields = {"slug": ("title",)}
    list_display = ("title", "slug", "category", "created_by", "created_at")
    list_filter = ("category", "created_by")
    search_fields = ("title",)

    def view_on_site(self, obj):
        return obj.get_absolute_url()

@admin.register(Post)
class PostAdmin(admin.ModelAdmin):
    list_display = ("thread", "created_by", "created_at")
    list_filter = ("created_by",)
    search_fields = ("content",)