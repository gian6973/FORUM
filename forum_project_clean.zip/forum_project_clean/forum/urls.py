from django.urls import path
from . import views  # Προσθήκη αυτής της γραμμής

app_name = 'forum'

urlpatterns = [
    path('', views.home, name='home'),
    path('signup/', views.signup_view, name='signup'),
    path('categories/<int:category_id>/', views.category_threads, name='category_threads'),
    path('threads/<int:thread_id>/', views.thread_detail, name='thread_detail'),
    path('threads/new/<int:category_id>/', views.new_thread, name='new_thread'),
    path('profile/edit/', views.profile_edit, name='profile_edit'),
    path('posts/new/<int:thread_id>/', views.create_post, name='create_post'),
]

#from django.urls import path
#from forum.custom_auth import signup_view  # Αλλαγή εδώ
#from forum.views import (
#    home,
#    signup_view,  # Προσθήκη αυτής της γραμμής
#    category_threads,
#    thread_detail,
#    new_thread,
#    subcategory_threads,
#    profile_edit,
#    create_post
#)

#app_name = 'forum'

#urlpatterns = [
#    path('', home, name='home'),
#    path('signup/', signup_view, name='signup'),  # Απευθείας χρήση της συνάρτησης
#    path('categories/<int:category_id>/', views.category_threads, name='category_threads'),
#    path('categories/<int:category_id>/old/', RedirectView.as_view(pattern_name='forum:category_threads')),
#	 path('threads/<int:thread_id>/', thread_detail, name='thread_detail'),
#    path('threads/new/<int:category_id>/', new_thread, name='new_thread'),
#    path('profile/edit/', profile_edit, name='profile_edit'),
#    path('posts/new/<int:thread_id>/', create_post, name='create_post'),
#]
# Προσθήκη στο urls.py

#path('categories/<int:category_id>/', category_threads, name='category_threads'),

