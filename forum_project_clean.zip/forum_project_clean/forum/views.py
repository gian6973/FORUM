from django.shortcuts import render, redirect, get_object_or_404
from django.core.paginator import Paginator
from django.contrib.auth.decorators import login_required
from django.contrib.auth import login
from django.http import HttpResponse, HttpResponseRedirect
from django.urls import reverse
from django import forms
from .models import Category, Thread, Post
from .forms import ThreadForm
from django.contrib.auth.forms import UserCreationForm


def signup_view(request):
    if request.method == 'POST':
        form = UserCreationForm(request.POST)
        if form.is_valid():
            user = form.save()
            login(request, user)
            return redirect('forum:home')
    else:
        form = UserCreationForm()
    return render(request, 'registration/signup.html', {'form': form})

def home(request):
    """Αρχική σελίδα με κατηγορίες"""
    categories = Category.objects.filter(parent__isnull=True).prefetch_related(
        'children__threads', 
        'threads'
    )
    return render(request, 'forum/home.html', {'categories': categories})


def category_threads(request, category_id):
    """Λίστα θεμάτων ανά κατηγορία"""
    category = get_object_or_404(Category, id=category_id)
    thread_list = Thread.objects.filter(category=category).order_by('-created_at')
    
    paginator = Paginator(thread_list, 10)
    page_number = request.GET.get('page')
    threads = paginator.get_page(page_number)
    
    return render(request, 'forum/category_threads.html', {
        'category': category,
        'threads': threads
    })


def thread_detail(request, thread_id):
    """Λεπτομέρειες θέματος και απαντήσεις"""
    thread = get_object_or_404(Thread, id=thread_id)
    posts = Post.objects.filter(thread=thread).order_by('created_at')
    category_ancestors = thread.category.get_ancestors(include_self=True)
    
    return render(request, 'forum/thread_detail.html', {
        'thread': thread,
        'posts': posts,
        'category_ancestors': category_ancestors
    })


@login_required
def new_thread(request, category_id):
    """Δημιουργία νέου θέματος"""
    category = get_object_or_404(Category, id=category_id)

    if request.method == 'POST':
        form = ThreadForm(request.POST)
        if form.is_valid():
            thread = form.save(commit=False)
            thread.category = category
            thread.author = request.user
            thread.save()

            Post.objects.create(
                thread=thread,
                author=request.user,
                content=form.cleaned_data['content']
            )
            return HttpResponseRedirect(
                reverse('forum:thread_detail', args=[thread.id])
            )
    else:
        form = ThreadForm()

    return render(request, 'forum/new_thread.html', {
        'form': form,
        'category': category
    })


def subcategory_threads(request, subcategory_slug):
    """Θέματα υποκατηγορίας (με slug)"""
    subcategory = get_object_or_404(Category, slug=subcategory_slug)
    threads = Thread.objects.filter(category=subcategory).order_by('-created_at')
    
    paginator = Paginator(threads, 10)
    page_number = request.GET.get('page')
    threads_page = paginator.get_page(page_number)
    
    return render(request, 'forum/subcategory_threads.html', {
        'subcategory': subcategory,
        'threads': threads_page
    })


def profile_edit(request):
    """Σελίδα επεξεργασίας προφίλ"""
    return HttpResponse("Η σελίδα επεξεργασίας προφίλ δεν είναι ακόμα διαθέσιμη.")


class PostForm(forms.ModelForm):
    """Φόρμα δημιουργίας απάντησης"""
    class Meta:
        model = Post
        fields = ['content']
        widgets = {
            'content': forms.Textarea(attrs={
                'rows': 4, 
                'placeholder': 'Γράψε την απάντησή σου εδώ...'
            })
        }


@login_required
def create_post(request, thread_id):
    """Δημιουργία νέας απάντησης"""
    thread = get_object_or_404(Thread, id=thread_id)

    if request.method == 'POST':
        form = PostForm(request.POST)
        if form.is_valid():
            post = form.save(commit=False)
            post.thread = thread
            post.author = request.user
            post.save()
            return HttpResponseRedirect(
                reverse('forum:thread_detail', args=[thread.id])
            )
    else:
        form = PostForm()

    return render(request, 'forum/create_post.html', {
        'thread': thread,
        'form': form
    })
	
	