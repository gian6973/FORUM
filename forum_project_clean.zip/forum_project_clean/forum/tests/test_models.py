from django.test import TestCase
from django.contrib.auth.models import User
from forum.models import Category, Thread, Post

class ForumModelsTestCase(TestCase):

    def setUp(self):
        # Δημιουργία χρήστη
        self.user = User.objects.create_user(username='tester', password='password')

        # Δημιουργία κύριας κατηγορίας
        self.category = Category.objects.create(name='Γενικά Θέματα')

        # Δημιουργία thread
        self.thread = Thread.objects.create(
            title='Καλωσόρισμα',
            category=self.category,
            creator=self.user
        )

        # Δημιουργία post
        self.post = Post.objects.create(
            thread=self.thread,
            author=self.user,
            content='Γεια σε όλους!'
        )

    def test_category_creation(self):
        self.assertEqual(self.category.name, 'Γενικά Θέματα')
        self.assertIsNotNone(self.category.slug)

    def test_thread_creation(self):
        self.assertEqual(self.thread.title, 'Καλωσόρισμα')
        self.assertEqual(self.thread.category, self.category)
        self.assertEqual(self.thread.creator, self.user)

    def test_post_creation(self):
        self.assertEqual(self.post.content, 'Γεια σε όλους!')
        self.assertEqual(self.post.thread, self.thread)
        self.assertEqual(self.post.author, self.user)
