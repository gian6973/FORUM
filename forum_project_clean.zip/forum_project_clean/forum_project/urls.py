from django.contrib import admin
from django.urls import path, include
from django.contrib.auth import views as auth_views

urlpatterns = [
    path('admin/', admin.site.urls),
    # ΑΦΑΙΡΕΣΤΕ αυτή τη γραμμή: path('', include(forum_urls, namespace='forum')),
    path('', include('forum.urls')),  # Μόνο αυτή η γραμμή για τα forum URLs
    path('login/', auth_views.LoginView.as_view(), name='login'),
    path('logout/', auth_views.LogoutView.as_view(), name='logout'),
]