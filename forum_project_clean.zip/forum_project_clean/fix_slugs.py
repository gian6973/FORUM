# fix_slugs.py

from forum.models import Category
from collections import defaultdict

slug_map = defaultdict(list)

# Συλλογή όλων των slugs και των αντίστοιχων Category
for cat in Category.objects.all():
    slug_map[cat.slug].append(cat)

# Εύρεση διπλότυπων slugs και διόρθωση
for slug, cats in slug_map.items():
    if len(cats) > 1:
        for i, cat in enumerate(cats[1:], start=1):  # πρώτο μένει ίδιο, αλλά τα υπόλοιπα αλλάζουν
            new_slug = f"{cat.slug}-{i}"
            print(f"Fixing slug '{cat.slug}' (id={cat.id}) -> '{new_slug}'")
            cat.slug = new_slug
            cat.save()

print("✅ Slugs updated successfully.")
